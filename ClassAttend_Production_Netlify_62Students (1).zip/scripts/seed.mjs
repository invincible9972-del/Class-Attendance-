import {neon} from '@neondatabase/serverless';import bcrypt from 'bcryptjs';
const sql=neon(process.env.DATABASE_URL);if(!process.env.DATABASE_URL)throw new Error('DATABASE_URL required');
const hash=await bcrypt.hash('ChangeMe123!',12);
const [t]=await sql`INSERT INTO users(name,email,password_hash,role) VALUES('Demo Teacher','teacher@example.com',${hash},'teacher') ON CONFLICT(email) DO UPDATE SET password_hash=EXCLUDED.password_hash RETURNING id`;
const [s1]=await sql`INSERT INTO users(name,email,password_hash,role) VALUES('Aarav Student','student@example.com',${hash},'student') ON CONFLICT(email) DO UPDATE SET password_hash=EXCLUDED.password_hash RETURNING id`;
const [s2]=await sql`INSERT INTO users(name,email,password_hash,role) VALUES('Priya Student','priya@example.com',${hash},'student') ON CONFLICT(email) DO UPDATE SET password_hash=EXCLUDED.password_hash RETURNING id`;
const [c]=await sql`INSERT INTO classes(teacher_id,name) VALUES(${t.id},'Physics') RETURNING id`;const [b]=await sql`INSERT INTO batches(class_id,name) VALUES(${c.id},'Batch A') RETURNING id`;await sql`INSERT INTO batch_members(batch_id,student_id) VALUES(${b.id},${s1.id}),(${b.id},${s2.id}) ON CONFLICT DO NOTHING`;console.log('Seeded. Demo password: ChangeMe123!');

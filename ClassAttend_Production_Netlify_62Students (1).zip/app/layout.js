import './globals.css';
export const metadata={title:'ClassAttend',description:'Teacher and student attendance management'};
export default function RootLayout({children}){return <html lang="en"><body>{children}</body></html>}

import {requireUser} from '../../../../lib/auth';import {json,fail} from '../../../../lib/api';
export async function GET(){try{return json({user:await requireUser()})}catch{return fail('Unauthorized',401)}}

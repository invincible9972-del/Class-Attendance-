import {sql} from '../../../../lib/db';
import {hashPassword,setSession} from '../../../../lib/auth';
import {body,fail,json} from '../../../../lib/api';
export async function POST(req){
  try{
    const {name,email,password,joinCode}=await body(req);
    if(!name||!email||!password)return fail('Name, email and password are required');
    if(password.length<6)return fail('Password must be at least 6 characters');
    const exists=await sql()`SELECT id FROM users WHERE lower(email)=lower(${email})`;
    if(exists.length)return fail('An account with this email already exists',409);
    const h=await hashPassword(password);
    const u=(await sql()`INSERT INTO users(name,email,password_hash,role) VALUES(${name},${email},${h},'student') RETURNING id,name,email,role`)[0];
    if(joinCode){
      const b=await sql()`SELECT id FROM batches WHERE upper(join_code)=upper(${joinCode})`;
      if(!b.length)return fail('Account created, but the Join Code is invalid',400);
      await sql()`INSERT INTO batch_members(batch_id,student_id) VALUES(${b[0].id},${u.id}) ON CONFLICT DO NOTHING`;
    }
    await setSession(u);
    return json({user:u,joined:!!joinCode},201);
  }catch(e){return fail('Server error',500)}
}

import {requireUser} from '../../../lib/auth';
import {sql} from '../../../lib/db';
import {body,fail,json} from '../../../lib/api';
export async function POST(req){
 try{
  const u=await requireUser(); if(u.role!=='student')return fail('Student only',403);
  const {joinCode}=await body(req); if(!joinCode)return fail('Join Code is required');
  const b=await sql()`SELECT id,name FROM batches WHERE upper(join_code)=upper(${joinCode})`;
  if(!b.length)return fail('Invalid Join Code',404);
  await sql()`INSERT INTO batch_members(batch_id,student_id) VALUES(${b[0].id},${u.sub}) ON CONFLICT DO NOTHING`;
  return json({success:true,batch:b[0]});
 }catch(e){return fail(e.message==='UNAUTHORIZED'?'Unauthorized':'Server error',e.message==='UNAUTHORIZED'?401:500)}
}

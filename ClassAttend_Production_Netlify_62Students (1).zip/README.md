# ClassAttend — Production Netlify Starter

A real Next.js + PostgreSQL attendance system for teacher/student accounts, server-side attendance windows, batch Join Codes and QR joining.

## Recommended setup for a 62-student class

1. Create one PostgreSQL database (Neon is an easy option for a small deployment).
2. Run `db/schema.sql` in the database SQL editor.
3. Deploy this repository to Netlify.
4. Add environment variables in Netlify:
   - `DATABASE_URL` = your PostgreSQL connection string
   - `JWT_SECRET` = a long random secret (32+ characters)
5. Create your teacher account using the seed script or an admin provisioning method.
6. Teacher creates a class and a batch. Every batch gets a Join Code automatically.
7. Display the Join Code or QR code to the class.
8. Students create their own accounts and enter the Join Code. They can also join additional batches later.
9. Teacher starts a 10-minute (or other configured) attendance session.
10. Students mark attendance. The server checks enrollment, session state and server time.

## PostgreSQL: easiest method with Neon

- Go to https://neon.tech/ and create an account.
- Create a project and database.
- Open the SQL Editor.
- Paste all of `db/schema.sql` and run it.
- In the Neon dashboard, copy the connection string.
- In Netlify: Site configuration → Environment variables → add `DATABASE_URL` with that value.
- Generate a strong `JWT_SECRET` and add it too.
- Redeploy after changing environment variables.

Do not put the PostgreSQL password or JWT secret into frontend JavaScript or commit them to GitHub.

## Local development

```bash
npm install
cp .env.example .env.local
npm run dev
```

## Production notes

This starter is suitable for a classroom pilot. Before institutional production, add email verification/password reset, rate limiting, audit logs, admin provisioning, backups, report exports and a first-class QR generator rather than relying on the external QR image endpoint.
